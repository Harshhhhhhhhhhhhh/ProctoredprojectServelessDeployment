
export function handler(event) {
  const newTodo = JSON.parse(event.body)

  // TODO: Implement creating a new TODO item
  return undefined
}

