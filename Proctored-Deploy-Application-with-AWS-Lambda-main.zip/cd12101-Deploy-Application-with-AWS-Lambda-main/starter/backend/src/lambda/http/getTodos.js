export function handler(event) {
  // TODO: Get all TODO items for a current user
  return undefined
}
