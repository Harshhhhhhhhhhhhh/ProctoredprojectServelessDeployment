
export function handler(event) {
  const todoId = event.pathParameters.todoId

  // TODO: Remove a TODO item by id
  return undefined
}

